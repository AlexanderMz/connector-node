# filemanager-connector-node


### Run connector

**1) Install dependencies ```npm install```**

**2) Run server ```node app.js```**
